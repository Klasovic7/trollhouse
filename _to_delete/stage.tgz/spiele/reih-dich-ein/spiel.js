// ============================================================================
//  Reih dich ein!
// ----------------------------------------------------------------------------
//  Begriffe werden nacheinander in eine wachsende, aufsteigende Reihe gesetzt.
//  Alle Felder dieses Spiels im Raum-Dokument beginnen mit "rd".
// ============================================================================
import { updateDoc, runTransaction } from "../../kern/firebase.js";
import { escapeHtml, spielerKarte, zeigeDebug, initBereitSystem } from "../../kern/ui.js";
import { speichereWertung } from "../../kern/wertung.js";
import { pooleOhneWiederholung, aktualisierterVerlauf } from "../../kern/verlauf.js";
import {
  mischeListe, begriffNachId, richtigerEinfuegeIndex, fuegeEin, aktiveSpielerId,
  punkteNachAntwort
} from "./logik.js";

const VORLAGE = `
  <div id="rd-setup" class="bildschirm-karte" hidden>
    <h1>↕️ Reih dich ein!</h1>
    <p class="hinweis-text">Setzt jeden neuen Begriff an die richtige Stelle der Reihe. Ein Startbegriff ist
      bereits eingeordnet. Danach ist immer ein Spieler dran. Eine richtige Position gibt einen Pluspunkt –
      bei einer falschen Position gibt es einen Minuspunkt.</p>

    <div id="rd-anzahl-zeile" class="setup-anzahlblock" hidden>
      <div class="setup-anzahl-zeile">
        <span>Anzahl Kategorien</span>
        <span class="anzahl-picker">
          <input id="rd-anzahl" type="text" inputmode="numeric" pattern="[0-9]*" min="1" class="anzahl-eingabe">
        </span>
      </div>
      <p id="rd-anzahl-max" class="hinweis-text"></p>
    </div>

    <p id="rd-setup-fehler" class="fehler-text"></p>
    <p><button id="rd-starten" class="btn-primaer" hidden>Spiel starten</button></p>
    <p id="rd-setup-warten" hidden><em>Warte, bis der Spielleiter das Spiel startet …</em></p>
    <div id="rd-bereit-bereich" class="bereit-bereich" hidden></div>
  </div>

  <div id="rd-runde" class="bildschirm-karte" hidden>
    <p class="kategorie">Reih dich ein!</p>
    <p id="rd-fortschritt" class="fortschritt"></p>
    <div class="rd-kategorie-kopf">
      <h1 id="rd-titel"></h1>
      <p id="rd-frage"></p>
      <strong id="rd-richtung"></strong>
    </div>
    <div id="rd-aktiver-spieler" class="rd-aktiver-spieler"></div>
    <div id="rd-letztes-ergebnis" class="rd-letztes-ergebnis" hidden>
      <strong id="rd-letztes-ergebnis-titel"></strong>
      <span id="rd-letztes-ergebnis-text"></span>
    </div>
    <div class="rd-kandidat">
      <strong id="rd-kandidat"></strong>
    </div>
    <p id="rd-runde-fehler" class="fehler-text"></p>
    <div class="rd-sortierbereich">
      <aside class="rd-skala" aria-label="Sortierrichtung">
        <span id="rd-skala-oben"></span><i></i><span id="rd-skala-unten"></span>
      </aside>
      <div id="rd-reihe" class="rd-reihe"></div>
    </div>
    <div id="rd-zwischenstand"></div>
    <p class="rd-kategorie-wechsel">
      <button id="rd-andere-kategorie" class="btn-flach" hidden>Andere Kategorie</button>
    </p>
  </div>

  <div id="rd-feedback" class="bildschirm-karte" hidden>
    <p class="kategorie">Reih dich ein!</p>
    <p id="rd-feedback-fortschritt" class="fortschritt"></p>
    <div class="rd-kategorie-ergebnis-kopf">
      <strong>Kategorie abgeschlossen!</strong>
      <span>So wurden die Begriffe eingeordnet:</span>
    </div>
    <h2 id="rd-feedback-kategorie"></h2>
    <p id="rd-feedback-richtung" class="hinweis-text"></p>
    <div id="rd-feedback-reihe" class="rd-ergebnis-reihe"></div>
    <div id="rd-feedback-punkte"></div>
    <p><button id="rd-naechste-kategorie" class="btn-primaer" hidden>Nächste Kategorie</button></p>
    <p id="rd-feedback-warten" hidden><em>Der Spielleiter startet gleich die nächste Kategorie …</em></p>
  </div>

  <div id="rd-endstand" class="bildschirm-karte" hidden>
    <h1>🏁 Endstand</h1>
    <p class="hinweis-text">Wer die meisten Punkte gesammelt hat, gewinnt.</p>
    <div id="rd-endstand-inhalt"></div>
    <p id="rd-endstand-warten" hidden><em>Der Spielleiter wählt gleich das nächste Spiel …</em></p>
    <p><button id="rd-gesamtwertung-btn" class="btn-primaer" type="button" hidden>Gesamtwertung</button></p>
  </div>
`;

let api = null;
let el = {};
let karten = [];
let spielerListe = [];
let status = null;
let kategorienReihenfolge = [];
let anzahlKategorien = 0;
let anzahlEntwurf = null;
let anzahlEntwurfTimer = null;
let kategorieIndex = 0;
let begriffeReihenfolge = [];
let begriffIndex = 0;
let sortierteIds = [];
let spielerReihenfolge = [];
let zugIndex = 0;
let aktiveId = null;
let punkte = {};
let ergebnisse = {};
let letzteRichtig = null;
let letzterBegriffId = null;
let letzterSpielerId = null;
let verworfeneKategorien = [];
let gespielt = []; // Indizes der zuletzt gespielten Kategorien/Karten (fuer Wiederholungsschutz)
let aktionLaeuft = false;
let anzahlManuellGesetzt = false;
let spielerwechselLaeuft = false;

const $ = (id) => el.wurzel.querySelector("#" + id);

function aktuelleKarte() {
  return karten[kategorienReihenfolge[kategorieIndex]] ?? null;
}

function aktuellerBegriff() {
  return begriffNachId(aktuelleKarte(), begriffeReihenfolge[begriffIndex]);
}

function spielerNachId(id) {
  return spielerListe.find((spieler) => spieler.id === id) ?? null;
}

// v112: die Kategorie-Zählung steht jetzt oben im Spielkopf (api.fortschritt) -
// hier bleibt nur noch die feinere Zählung innerhalb der aktuellen Kategorie.
function rundenFortschritt() {
  return `Begriff ${begriffIndex + 1} von ${begriffeReihenfolge.length}`;
}

function skalenBeschriftung(karte) {
  return Array.isArray(karte?.skala) && karte.skala.length === 2
    ? karte.skala
    : ["ANFANG", "ENDE"];
}

function neueKategorieDaten(karte) {
  const startId = begriffNachId(karte, karte.startId)
    ? karte.startId
    : [...karte.begriffe].sort((a, b) => a.wert - b.wert)[Math.floor(karte.begriffe.length / 2)].id;
  return {
    rdBegriffeReihenfolge: mischeListe(karte.begriffe.filter((begriff) => begriff.id !== startId).map((begriff) => begriff.id)),
    rdBegriffIndex: 0,
    rdSortierteIds: [startId],
    rdErgebnisse: {},
    rdLetzteRichtig: null,
    rdLetzterBegriffId: null,
    rdLetzterSpielerId: null
  };
}

// Bereit-System (v190) - siehe kern/ui.js
let bereitSystem = null;
// v199: verhindert, dass der Bereit-Auto-Start (siehe zeigeSetup) mehrfach feuert.
let olympiadeAutoStart = false;

export async function starten(uebergebeneApi) {
  api = uebergebeneApi;
  el.wurzel = api.wurzel;
  el.wurzel.innerHTML = VORLAGE;
  bereitSystem = initBereitSystem(api, "rd");
  olympiadeAutoStart = false;

  if (!karten.length) {
    const antwort = await fetch(new URL("fragen.json", import.meta.url), { cache: "no-store" });
    if (!antwort.ok) throw new Error("fragen.json konnte nicht geladen werden");
    karten = await antwort.json();
  }

  verdrahteBedienelemente();

  if (api.istLeiter && !api.raum?.rdStatus) {
    await updateDoc(api.raumRef(), {
      rdStatus: "setup", rdKategorienReihenfolge: [], rdAnzahlKategorien: 0, rdAnzahlEntwurf: 0,
      rdKategorieIndex: 0, rdBegriffeReihenfolge: [], rdBegriffIndex: 0,
      rdSortierteIds: [], rdSpielerReihenfolge: [], rdZugIndex: 0,
      rdAktiveId: null, rdPunkte: {}, rdErgebnisse: {}, rdLetzteRichtig: null, rdLetzterBegriffId: null,
      rdLetzterSpielerId: null,
      rdVerworfeneKategorien: []
    });
  }

  // v196/v199: Olympiade - die Anzahl steht schon vorab fest, wird hier nur
  // vorbelegt (Tick warten, bis spielerListe gefuellt ist). Gestartet wird
  // trotzdem erst, wenn alle Mitspieler*innen "Bereit" geklickt haben - das
  // uebernimmt der Aufruf in zeigeSetup() weiter unten.
  // v201: die Anzahl wird nicht mehr hier vorbelegt, sondern bei jedem
  // Render in zeigeSetup() direkt aus api.olympiadeAnzahl gesetzt (siehe
  // dort).
}

function verdrahteBedienelemente() {
  $("rd-anzahl").addEventListener("input", () => {
    const feld = $("rd-anzahl");
    const bereinigt = feld.value.replace(/[^0-9]/g, "");
    if (bereinigt !== feld.value) feld.value = bereinigt;
    anzahlManuellGesetzt = true;
    schreibeAnzahlEntwurfLive();
  });
  // v197: type="text" ignoriert das max-Attribut - ohne diese eigene
  // Begrenzung beim Verlassen des Feldes liesse sich eine beliebig hohe Zahl
  // eintippen, die stehen bliebe, bis sie beim Start still zurueckgestutzt wird.
  $("rd-anzahl").addEventListener("change", () => {
    const feld = $("rd-anzahl");
    let wert = parseInt(feld.value, 10);
    if (!Number.isFinite(wert) || wert < 1) wert = 1;
    if (wert > karten.length) wert = karten.length;
    feld.value = String(wert);
    anzahlManuellGesetzt = true;
  });
  // v105: als type="number" ließ sich der vorhandene Wert beim Fokussieren nicht
  // markieren - jetzt ein Textfeld mit numerischer Tastatur, select() funktioniert.
  $("rd-anzahl").addEventListener("focus", () => { $("rd-anzahl").select(); });
  $("rd-starten").addEventListener("click", spielStarten);
  $("rd-naechste-kategorie").addEventListener("click", naechsteKategorie);
  $("rd-andere-kategorie").addEventListener("click", andereKategorie);
}

// v214: Schreibt den vom Leiter eingegebenen "Anzahl"-Wert entprellt live in
// den Raum, damit Mitspieler*innen im Setup-Bildschirm sofort den
// tatsaechlichen Stand sehen statt eines stehengebliebenen Default-Werts.
function schreibeAnzahlEntwurfLive() {
  if (!api.istLeiter) return;
  clearTimeout(anzahlEntwurfTimer);
  anzahlEntwurfTimer = setTimeout(() => {
    const wert = parseInt($("rd-anzahl").value, 10);
    if (Number.isFinite(wert) && wert > 0) {
      updateDoc(api.raumRef(), { rdAnzahlEntwurf: wert }).catch(() => {});
    }
  }, 300);
}

export function beenden() {
  bereitSystem = null;
  api = null;
  el = {};
  karten = [];
  spielerListe = [];
  status = null;
  kategorienReihenfolge = [];
  anzahlKategorien = 0;
  anzahlEntwurf = null;
  kategorieIndex = 0;
  begriffeReihenfolge = [];
  begriffIndex = 0;
  sortierteIds = [];
  spielerReihenfolge = [];
  zugIndex = 0;
  aktiveId = null;
  punkte = {};
  ergebnisse = {};
  letzteRichtig = null;
  letzterBegriffId = null;
  letzterSpielerId = null;
  verworfeneKategorien = [];
  aktionLaeuft = false;
  anzahlManuellGesetzt = false;
  spielerwechselLaeuft = false;
}

export function spieler(liste) {
  spielerListe = liste;
  if (!el.wurzel) return;
  renderAktuellenStatus();

  if (api.istLeiter && status === "runde" && aktiveId && !spielerNachId(aktiveId) &&
      !aktionLaeuft && !spielerwechselLaeuft) {
    const neueAktiveId = aktiveSpielerId(spielerReihenfolge, zugIndex, spielerListe.map((spieler) => spieler.id));
    if (neueAktiveId) {
      spielerwechselLaeuft = true;
      updateDoc(api.raumRef(), { rdAktiveId: neueAktiveId })
        .catch((e) => zeigeDebug("Aktiver Spieler konnte nicht gewechselt werden: " + e.message))
        .finally(() => { spielerwechselLaeuft = false; });
    }
  }
}

export function raumDaten(daten) {
  if (!daten || !el.wurzel) return;
  status = daten.rdStatus ?? null;
  kategorienReihenfolge = daten.rdKategorienReihenfolge ?? [];
  anzahlKategorien = daten.rdAnzahlKategorien ?? 0;
  anzahlEntwurf = daten.rdAnzahlEntwurf ?? null;
  kategorieIndex = daten.rdKategorieIndex ?? 0;
  begriffeReihenfolge = daten.rdBegriffeReihenfolge ?? [];
  begriffIndex = daten.rdBegriffIndex ?? 0;
  sortierteIds = daten.rdSortierteIds ?? [];
  spielerReihenfolge = daten.rdSpielerReihenfolge ?? [];
  zugIndex = daten.rdZugIndex ?? 0;
  aktiveId = daten.rdAktiveId ?? null;
  punkte = daten.rdPunkte ?? {};
  ergebnisse = daten.rdErgebnisse ?? {};
  letzteRichtig = typeof daten.rdLetzteRichtig === "boolean" ? daten.rdLetzteRichtig : null;
  letzterBegriffId = daten.rdLetzterBegriffId ?? null;
  letzterSpielerId = daten.rdLetzterSpielerId ?? null;
  verworfeneKategorien = daten.rdVerworfeneKategorien ?? [];
  gespielt = daten.rdGespielt ?? [];
  renderAktuellenStatus();
}

function renderAktuellenStatus() {
  if (!el.wurzel) return;
  ["rd-setup", "rd-runde", "rd-feedback", "rd-endstand"]
    .forEach((id) => { $(id).hidden = true; });

  // v112: die äußere Kategorie-Zählung ("Kategorie X von Y") steht jetzt oben
  // im Spielkopf statt auf jedem einzelnen Bildschirm separat (siehe
  // api.fortschritt) - auf dem Bildschirm selbst bleibt nur noch die feinere
  // Zählung innerhalb der Kategorie ("Begriff X von Y", siehe rundenFortschritt).
  api.fortschritt(
    status === "runde" || status === "feedback" ? `${kategorieIndex + 1}/${anzahlKategorien}` : ""
  );

  if (status === "setup" || !status) {
    zeigeSetup();
    $("rd-setup").hidden = false;
  } else if (status === "runde") {
    zeigeRunde();
    $("rd-runde").hidden = false;
  } else if (status === "feedback") {
    zeigeFeedback();
    $("rd-feedback").hidden = false;
  } else if (status === "beendet") {
    zeigeEndstand();
    $("rd-endstand").hidden = false;
  }
}

function zeigeSetup() {
  const anzahlFeld = $("rd-anzahl");
  anzahlFeld.max = karten.length;
  const inOlympiade = Boolean(api.olympiadeAnzahl);
  if (inOlympiade) {
    // v201-Fix: vorher wurde die Anzahl nur einmalig beim Leiter per
    // setTimeout in starten() vorbelegt - jeder weitere zeigeSetup()-Aufruf
    // hat sie wieder zurueckgesetzt (anzahlManuellGesetzt blieb false), und
    // bei Mitspieler*innen wurde sie nie gesetzt. api.olympiadeAnzahl ist bei
    // allen Clients gleichermaßen verfuegbar - bei jedem Render fest darauf
    // setzen und das Feld komplett sperren.
    const festgelegt = Math.min(Math.max(1, api.olympiadeAnzahl), karten.length);
    anzahlFeld.value = String(festgelegt);
    $("rd-anzahl-max").textContent = `In der Olympiade festgelegt: ${festgelegt} Kategorie${festgelegt === 1 ? "" : "n"}.`;
    anzahlFeld.disabled = true;
  } else if (api.istLeiter) {
    if (!anzahlManuellGesetzt || !anzahlFeld.value) anzahlFeld.value = Math.min(3, karten.length);
    $("rd-anzahl-max").textContent = `Insgesamt ${karten.length} Kategorien verfügbar.`;
    anzahlFeld.disabled = false;
  } else {
    anzahlFeld.value = String(anzahlEntwurf ?? Math.min(3, karten.length));
    $("rd-anzahl-max").textContent = `Insgesamt ${karten.length} Kategorien verfügbar.`;
    anzahlFeld.disabled = true;
  }
  $("rd-anzahl-zeile").hidden = false;
  $("rd-starten").hidden = !api.istLeiter;
  $("rd-setup-warten").hidden = api.istLeiter;
  bereitSystem?.render();

  // v199: In der Olympiade ist die Anzahl schon vorab festgelegt, aber es
  // soll trotzdem ganz normal erst "Bereit" geklickt werden muessen - sobald
  // alle Mitspieler*innen bereit sind, startet das Spiel automatisch, ohne
  // dass der Leiter selbst noch auf "Spiel starten" tippen muss.
  if (api.istLeiter && api.olympiadeAnzahl && !olympiadeAutoStart && bereitSystem?.alleBereit()) {
    olympiadeAutoStart = true;
    spielStarten();
  }
}

async function spielStarten() {
  $("rd-setup-fehler").textContent = "";
  if (spielerListe.length < 2) {
    $("rd-setup-fehler").textContent = "Für Reih dich ein! braucht ihr mindestens zwei Spieler.";
    return;
  }

  let anzahl = parseInt($("rd-anzahl").value, 10);
  if (!Number.isFinite(anzahl) || anzahl < 1) anzahl = 1;
  if (anzahl > karten.length) anzahl = karten.length;

  // Wiederholungsschutz: bevorzugt Karten ziehen, die in diesem Raum noch
  // nicht drankamen (siehe kern/verlauf.js).
  const { kandidaten, wurdeZurueckgesetzt } = pooleOhneWiederholung(karten.map((_, index) => index), gespielt, anzahl);
  const kategorien = mischeListe(kandidaten).slice(0, anzahl);
  const neuerGespielt = aktualisierterVerlauf(gespielt, kategorien, wurdeZurueckgesetzt);
  const reihenfolge = mischeListe(spielerListe.map((spieler) => spieler.id));
  const ersteKategorie = neueKategorieDaten(karten[kategorien[0]]);
  $("rd-starten").disabled = true;
  try {
    await updateDoc(api.raumRef(), {
      rdStatus: "runde",
      rdKategorienReihenfolge: kategorien,
      rdAnzahlKategorien: anzahl,
      rdKategorieIndex: 0,
      ...ersteKategorie,
      rdSpielerReihenfolge: reihenfolge,
      rdZugIndex: 0,
      rdAktiveId: aktiveSpielerId(reihenfolge, 0, spielerListe.map((spieler) => spieler.id)),
      rdPunkte: Object.fromEntries(spielerListe.map((spieler) => [spieler.id, 0])),
      rdVerworfeneKategorien: [],
      rdGespielt: neuerGespielt
    });
  } catch (e) {
    zeigeDebug("Spiel konnte nicht gestartet werden: " + e.message);
    $("rd-starten").disabled = false;
  }
}

function formatiertePunkte(wert) {
  const punktewert = Number(wert) || 0;
  return punktewert > 0 ? `+${punktewert}` : `${punktewert}`;
}

function kategorienPunkte() {
  const aenderungen = {};
  Object.values(ergebnisse).forEach((ergebnis) => {
    if (!ergebnis?.spielerId) return;
    aenderungen[ergebnis.spielerId] = (aenderungen[ergebnis.spielerId] ?? 0) +
      (ergebnis.richtig ? 1 : -1);
  });
  return aenderungen;
}

function punktestandHtml(mitKategorienPunkten = true) {
  const sortiert = [...spielerListe].sort((a, b) =>
    (punkte[b.id] ?? 0) - (punkte[a.id] ?? 0)
  );
  const aenderungen = kategorienPunkte();
  return `<ul class="rd-punkteliste">${sortiert.map((spieler, index) => {
    const gesamt = punkte[spieler.id] ?? 0;
    return `<li>${mitKategorienPunkten
      ? spielerKarte(
          spieler.name, spieler.farbe, spieler.icon,
          formatiertePunkte(aenderungen[spieler.id] ?? 0),
          { punkteRechts: gesamt }
        )
      : spielerKarte(spieler.name, spieler.farbe, spieler.icon, gesamt, { rang: index + 1 })
    }</li>`;
  }).join("")}</ul>`;
}

function begriffKarteHtml(begriff, hervorgehoben = false) {
  if (!begriff) return "";
  return `<div class="rd-reihen-begriff${hervorgehoben ? " neu" : ""}">` +
    `<strong>${escapeHtml(begriff.name)}</strong><span>${escapeHtml(begriff.wertText)}</span></div>`;
}

function rendereReihe(container, mitPositionen) {
  const karte = aktuelleKarte();
  container.innerHTML = "";
  if (!karte) return;
  const darfWaehlen = mitPositionen && api.spielerId === aktiveId;

  for (let index = 0; index <= sortierteIds.length; index++) {
    if (mitPositionen) {
      const position = document.createElement("button");
      position.type = "button";
      position.className = "rd-position";
      position.disabled = !darfWaehlen || aktionLaeuft;
      position.textContent = darfWaehlen ? "Hier einordnen" : "•";
      position.setAttribute("aria-label", `An Position ${index + 1} einordnen`);
      if (darfWaehlen) position.addEventListener("click", () => waehlePosition(index));
      container.appendChild(position);
    }
    if (index < sortierteIds.length) {
      const begriff = begriffNachId(karte, sortierteIds[index]);
      const wrapper = document.createElement("div");
      wrapper.innerHTML = begriffKarteHtml(begriff, begriff?.id === letzterBegriffId);
      container.appendChild(wrapper.firstElementChild);
    }
  }
}

function rendereKategorieErgebnis(container) {
  const karte = aktuelleKarte();
  container.innerHTML = "";
  if (!karte) return;

  for (const begriffId of sortierteIds) {
    const begriff = begriffNachId(karte, begriffId);
    if (!begriff) continue;
    const ergebnis = ergebnisse[begriffId] ?? null;
    const zeile = document.createElement("div");
    zeile.className = "rd-ergebnis-begriff";

    const kopf = document.createElement("div");
    kopf.className = "rd-ergebnis-begriff-kopf";
    const name = document.createElement("strong");
    name.textContent = begriff.name;
    const wert = document.createElement("span");
    wert.textContent = begriff.wertText;
    kopf.append(name, wert);

    const meta = document.createElement("div");
    meta.className = "rd-ergebnis-meta";
    const spielerAnzeige = document.createElement("div");
    spielerAnzeige.className = "rd-ergebnis-spieler";
    const wertung = document.createElement("strong");
    if (ergebnis) {
      const spieler = spielerNachId(ergebnis.spielerId);
      spielerAnzeige.innerHTML = spielerKarte(
        ergebnis.spielerName || spieler?.name || "Spieler",
        ergebnis.spielerFarbe || spieler?.farbe,
        ergebnis.spielerIcon || spieler?.icon,
        0,
        { punkteLinks: false }
      );
      wertung.className = ergebnis.richtig ? "richtig" : "falsch";
      wertung.textContent = ergebnis.richtig ? "+1" : "−1";
    } else {
      spielerAnzeige.classList.add("neutral");
      spielerAnzeige.textContent = begriffId === karte.startId ? "Startbegriff" : "Nicht erfasst";
      wertung.className = "neutral";
      wertung.textContent = "–";
    }
    meta.append(spielerAnzeige, wertung);
    zeile.append(kopf, meta);
    container.appendChild(zeile);
  }
}

function zeigeRunde() {
  const karte = aktuelleKarte();
  const kandidat = aktuellerBegriff();
  if (!karte || !kandidat) return;
  const aktiverSpieler = spielerNachId(aktiveId);
  $("rd-fortschritt").textContent = rundenFortschritt();
  $("rd-titel").textContent = karte.titel;
  $("rd-frage").textContent = karte.frage;
  $("rd-richtung").textContent = karte.richtung;
  const [oben, unten] = skalenBeschriftung(karte);
  $("rd-skala-oben").textContent = oben;
  $("rd-skala-unten").textContent = unten;
  $("rd-aktiver-spieler").innerHTML = aktiverSpieler
    ? spielerKarte(`${aktiverSpieler.name} ist dran`, aktiverSpieler.farbe, aktiverSpieler.icon, 0, { punkteLinks: false })
    : "Ein Spieler ist dran";
  const ergebnisBox = $("rd-letztes-ergebnis");
  if (typeof letzteRichtig === "boolean") {
    const letzterSpieler = spielerNachId(letzterSpielerId);
    const letzterName = ergebnisse[letzterBegriffId]?.spielerName || letzterSpieler?.name || "Der vorherige Spieler";
    ergebnisBox.hidden = false;
    ergebnisBox.className = `rd-letztes-ergebnis ${letzteRichtig ? "richtig" : "falsch"}`;
    $("rd-letztes-ergebnis-titel").textContent = letzteRichtig ? "Richtig: +1" : "Falsch: −1";
    $("rd-letztes-ergebnis-text").textContent =
      `${letzterName} hat ${letzteRichtig ? "richtig" : "falsch"} eingeordnet.`;
  } else {
    ergebnisBox.hidden = true;
  }
  $("rd-kandidat").textContent = kandidat.name;
  rendereReihe($("rd-reihe"), true);
  $("rd-andere-kategorie").hidden = !api.istLeiter;
  $("rd-andere-kategorie").disabled = aktionLaeuft;
  $("rd-zwischenstand").innerHTML = `<h3>Zwischenstand</h3>${punktestandHtml()}`;
}

async function andereKategorie() {
  if (!api.istLeiter || status !== "runde" || aktionLaeuft) return;
  const knopf = $("rd-andere-kategorie");
  knopf.disabled = true;
  $("rd-runde-fehler").textContent = "";
  const erwarteteKategorie = kategorienReihenfolge[kategorieIndex];
  aktionLaeuft = true;
  let keinErsatz = false;
  try {
    await runTransaction(api.db, async (transaktion) => {
      keinErsatz = false;
      const ref = api.raumRef();
      const snap = await transaktion.get(ref);
      const daten = snap.data();
      if (!daten || daten.rdStatus !== "runde") return;

      const katIndex = daten.rdKategorieIndex ?? 0;
      const aktuelleReihenfolge = daten.rdKategorienReihenfolge ?? [];
      if (aktuelleReihenfolge[katIndex] !== erwarteteKategorie) return;

      const verwendet = new Set(aktuelleReihenfolge);
      const bisherVerworfen = daten.rdVerworfeneKategorien ?? [];
      const verworfen = new Set(bisherVerworfen);
      const moegliche = mischeListe(karten.map((_, index) => index).filter((index) =>
        !verwendet.has(index) && !verworfen.has(index)
      ));
      if (!moegliche.length) {
        keinErsatz = true;
        return;
      }

      const neueReihenfolge = [...aktuelleReihenfolge];
      neueReihenfolge[katIndex] = moegliche[0];
      transaktion.update(ref, {
        rdKategorienReihenfolge: neueReihenfolge,
        rdVerworfeneKategorien: [...bisherVerworfen, erwarteteKategorie],
        ...neueKategorieDaten(karten[moegliche[0]])
      });
    });
    if (keinErsatz) {
      $("rd-runde-fehler").textContent = "Es ist keine andere ungespielte Kategorie mehr verfügbar.";
    }
  } catch (e) {
    zeigeDebug("Kategorie konnte nicht gewechselt werden: " + e.message);
  }
  aktionLaeuft = false;
  renderAktuellenStatus();
}

async function waehlePosition(index) {
  if (status !== "runde" || api.spielerId !== aktiveId || aktionLaeuft) return;
  const erwarteteKategorie = kategorienReihenfolge[kategorieIndex];
  const erwarteterBegriff = begriffeReihenfolge[begriffIndex];
  aktionLaeuft = true;
  renderAktuellenStatus();
  try {
    await runTransaction(api.db, async (transaktion) => {
      const ref = api.raumRef();
      const snap = await transaktion.get(ref);
      const daten = snap.data();
      if (!daten || daten.rdStatus !== "runde" || daten.rdAktiveId !== api.spielerId) return;

      const katIndex = daten.rdKategorieIndex ?? 0;
      const kartenIndex = (daten.rdKategorienReihenfolge ?? [])[katIndex];
      const karte = karten[kartenIndex];
      const begriffId = (daten.rdBegriffeReihenfolge ?? [])[daten.rdBegriffIndex ?? 0];
      const aktuelleReihe = daten.rdSortierteIds ?? [];
      if (kartenIndex !== erwarteteKategorie || begriffId !== erwarteterBegriff || !karte ||
          !Number.isInteger(index) || index < 0 || index > aktuelleReihe.length) return;

      const richtigerIndex = richtigerEinfuegeIndex(karte, aktuelleReihe, begriffId);
      const richtig = index === richtigerIndex;
      const neuePunkte = { ...(daten.rdPunkte ?? {}) };
      neuePunkte[api.spielerId] = punkteNachAntwort(neuePunkte[api.spielerId], richtig);
      const neueReihe = fuegeEin(aktuelleReihe, begriffId, richtigerIndex);
      const aktuellerBegriffIndex = daten.rdBegriffIndex ?? 0;
      const begriffsReihenfolge = daten.rdBegriffeReihenfolge ?? [];
      const naechsterZug = (daten.rdZugIndex ?? 0) + 1;
      const spielReihenfolge = daten.rdSpielerReihenfolge ?? [];
      const geladeneSpielerIds = spielerListe.map((spieler) => spieler.id);
      const naechsteAktiveId = aktiveSpielerId(
        spielReihenfolge,
        naechsterZug,
        geladeneSpielerIds.length ? geladeneSpielerIds : spielReihenfolge
      );
      const aktuellerSpieler = spielerNachId(api.spielerId);
      const ergebnis = {
        rdPunkte: neuePunkte,
        rdErgebnisse: {
          ...(daten.rdErgebnisse ?? {}),
          [begriffId]: {
            spielerId: api.spielerId,
            spielerName: api.spielerName || aktuellerSpieler?.name || "Spieler",
            spielerFarbe: aktuellerSpieler?.farbe ?? null,
            spielerIcon: aktuellerSpieler?.icon ?? null,
            richtig
          }
        },
        rdLetzteRichtig: richtig,
        rdLetzterBegriffId: begriffId,
        rdLetzterSpielerId: api.spielerId
      };

      if (aktuellerBegriffIndex + 1 < begriffsReihenfolge.length) {
        transaktion.update(ref, {
          ...ergebnis,
          rdStatus: "runde",
          rdSortierteIds: neueReihe,
          rdBegriffIndex: aktuellerBegriffIndex + 1,
          rdZugIndex: naechsterZug,
          rdAktiveId: naechsteAktiveId
        });
      } else {
        transaktion.update(ref, {
          ...ergebnis,
          rdStatus: "feedback",
          rdSortierteIds: neueReihe,
          rdZugIndex: naechsterZug,
          rdAktiveId: null
        });
      }
    });
  } catch (e) {
    zeigeDebug("Position konnte nicht gespeichert werden: " + e.message);
  }
  aktionLaeuft = false;
  renderAktuellenStatus();
}

function zeigeFeedback() {
  const karte = aktuelleKarte();
  if (!karte) return;
  $("rd-feedback-fortschritt").textContent = rundenFortschritt();
  $("rd-feedback-kategorie").textContent = karte.titel;
  $("rd-feedback-richtung").textContent = `${karte.frage} · ${karte.richtung}`;
  rendereKategorieErgebnis($("rd-feedback-reihe"));
  $("rd-feedback-punkte").innerHTML = `<h3>Zwischenstand</h3>${punktestandHtml()}`;
  $("rd-naechste-kategorie").hidden = !api.istLeiter;
  $("rd-naechste-kategorie").disabled = aktionLaeuft;
  $("rd-naechste-kategorie").textContent = kategorieIndex + 1 < anzahlKategorien
    ? "Nächste Kategorie"
    : "Endstand anzeigen";
  $("rd-feedback-warten").hidden = api.istLeiter;
  $("rd-feedback-warten").innerHTML = kategorieIndex + 1 < anzahlKategorien
    ? "<em>Der Spielleiter startet gleich die nächste Kategorie …</em>"
    : "<em>Der Spielleiter zeigt gleich den Endstand …</em>";
}

async function naechsteKategorie() {
  if (!api.istLeiter || status !== "feedback" || aktionLaeuft) return;
  aktionLaeuft = true;
  $("rd-naechste-kategorie").disabled = true;
  const erwarteteKategorie = kategorienReihenfolge[kategorieIndex];
  // Wird innerhalb der Transaktion gesetzt, sobald der letzte Durchgang endet -
  // danach (auesserhalb, die Transaktion kann sonst nicht in eine andere
  // Sammlung schreiben) einmalig in der Wertung gespeichert.
  let endstandPunkte = null;
  try {
    await runTransaction(api.db, async (transaktion) => {
      const ref = api.raumRef();
      const snap = await transaktion.get(ref);
      const daten = snap.data();
      if (!daten || daten.rdStatus !== "feedback") return;

      const katIndex = daten.rdKategorieIndex ?? 0;
      const kategorien = daten.rdKategorienReihenfolge ?? [];
      if (kategorien[katIndex] !== erwarteteKategorie) return;

      if (katIndex + 1 >= (daten.rdAnzahlKategorien ?? 0)) {
        transaktion.update(ref, { rdStatus: "beendet", rdAktiveId: null });
        endstandPunkte = daten.rdPunkte ?? {};
        return;
      }

      const naechsterKategorieIndex = katIndex + 1;
      const naechsteKarte = karten[kategorien[naechsterKategorieIndex]];
      const spielReihenfolge = daten.rdSpielerReihenfolge ?? [];
      const geladeneSpielerIds = spielerListe.map((spieler) => spieler.id);
      const naechsteAktiveId = aktiveSpielerId(
        spielReihenfolge,
        daten.rdZugIndex ?? 0,
        geladeneSpielerIds.length ? geladeneSpielerIds : spielReihenfolge
      );
      transaktion.update(ref, {
        ...neueKategorieDaten(naechsteKarte),
        rdStatus: "runde",
        rdKategorieIndex: naechsterKategorieIndex,
        rdAktiveId: naechsteAktiveId
      });
    });
  } catch (e) {
    zeigeDebug("Nächste Kategorie konnte nicht gestartet werden: " + e.message);
  }
  if (endstandPunkte) speichereWertung(api, "reih-dich-ein", endstandPunkte);
  aktionLaeuft = false;
  renderAktuellenStatus();
}

function zeigeEndstand() {
  $("rd-endstand-inhalt").innerHTML = punktestandHtml(false);
  $("rd-endstand-warten").hidden = api.istLeiter;
  // v202: in einer laufenden Olympiade fuehrt dieser Button jetzt zur
  // Gesamtwertung statt direkt zum naechsten Spiel - "Naechstes Spiel"
  // gibt es von dort aus als eigenen Button (siehe oeffneWertungDialog()
  // in app.js). So bleibt der eigene Endstand erst einmal sichtbar.
  const rdGesamtwertungBtn = $("rd-gesamtwertung-btn");
  if (rdGesamtwertungBtn) {
    rdGesamtwertungBtn.hidden = !(api.istLeiter && Boolean(api.olympiadeAnzahl));
    rdGesamtwertungBtn.onclick = () => api.zeigeGesamtwertung();
  }
}

// v104: der eigene "← Spielauswahl"/"Zurück zur Spielauswahl"-Button
// (Setup- und Endstand-Bildschirm) ist entfernt, weil oben in der Kopfzeile
// bereits derselbe Button existiert (gleiches Muster wie in
// spiele/schaetzfragen/spiel.js, siehe dessen "vorZurueck"-Kommentar).
export async function vorZurueck() {
  try {
    await updateDoc(api.raumRef(), {
      rdStatus: null, rdKategorienReihenfolge: [], rdAnzahlKategorien: 0, rdAnzahlEntwurf: 0,
      rdKategorieIndex: 0, rdBegriffeReihenfolge: [], rdBegriffIndex: 0,
      rdSortierteIds: [], rdSpielerReihenfolge: [], rdZugIndex: 0,
      rdAktiveId: null, rdPunkte: {}, rdErgebnisse: {}, rdLetzteRichtig: null, rdLetzterBegriffId: null,
      rdLetzterSpielerId: null,
      rdVerworfeneKategorien: []
    });
    await api.zurueckZurAuswahl();
  } catch (e) {
    zeigeDebug("Fehler beim Zurückkehren: " + e.message);
  }
}
