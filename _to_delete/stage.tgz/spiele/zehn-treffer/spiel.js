// ============================================================================
//  10 Treffer!
// ----------------------------------------------------------------------------
//  Eine Person oder ein Team sieht nur den Oberbegriff und nennt passende
//  Assoziationen. Die Gegenseite sieht die zehn gesuchten Treffer und markiert
//  sie live. Alle Felder dieses Spiels im Raum-Dokument beginnen mit "zt".
// ============================================================================
import { updateDoc, runTransaction, serverTimestamp } from "../../kern/firebase.js";
import { escapeHtml, avatarHtml, spielerKarte, zeigeDebug, initBereitSystem } from "../../kern/ui.js";
import { speichereWertung } from "../../kern/wertung.js";
import { pooleOhneWiederholung, aktualisierterVerlauf } from "../../kern/verlauf.js";
import {
  mischeListe, erstelleTeams, ergaenzeFehlendeTeams, bereinigeTreffer, aktiveSpielerId, aktivesTeam
} from "./logik.js";

const TEAMS = {
  blau: { name: "Team Blau", emoji: "🔵" },
  rot: { name: "Team Rot", emoji: "🔴" }
};

const RUNDEN_DAUER_SEKUNDEN = 40;

const VORLAGE = `
  <div id="zt-setup" class="bildschirm-karte" hidden>
    <h1>💥 10 Treffer!</h1>
    <p class="hinweis-text">Ein Begriff wird angezeigt. Findet die zehn Antworten, die wir suchen. Eine
      Person oder ein Team rät. Alle anderen sehen die Trefferliste und tippen einen Begriff an, sobald
      er genannt wurde. Jeder Treffer gibt einen Punkt.</p>

    <div id="zt-teammodus-zeile" class="setup-modusblock">
      <div class="setup-moduszeile">
        <span class="modus-text-zeile">
          <span class="schalter-text">Teammodus</span>
          <details class="modus-info">
            <summary aria-label="Erklärung zum Teammodus">i</summary>
            <div>Jeder entscheidet sich für ein Team. Die Teams treten abwechselnd an - wer rät, sieht nur den Begriff, das andere Team markiert die Treffer.</div>
          </details>
        </span>
        <label class="schalter-zeile">
          <span class="schalter">
            <input type="checkbox" id="zt-teammodus">
            <span class="schalter-regler"></span>
          </span>
        </label>
      </div>
    </div>

    <div id="zt-teams" hidden>
      <div class="zt-team-grid">
        <button type="button" id="zt-team-wahl-blau" class="zt-team zt-team-blau zt-team-waehlbar">
          <h3>🔵 Team Blau</h3>
          <ul id="zt-team-blau"></ul>
        </button>
        <button type="button" id="zt-team-wahl-rot" class="zt-team zt-team-rot zt-team-waehlbar">
          <h3>🔴 Team Rot</h3>
          <ul id="zt-team-rot"></ul>
        </button>
      </div>
      <p><button id="zt-teams-zufall" class="btn-flach" hidden>Zufällige Teams</button></p>
    </div>

    <div id="zt-anzahl-zeile" class="setup-anzahlblock" hidden>
      <div class="setup-anzahl-zeile">
        <span>Anzahl Begriffe</span>
        <span class="anzahl-picker">
          <input id="zt-anzahl" type="text" inputmode="numeric" pattern="[0-9]*" min="1" class="anzahl-eingabe">
        </span>
      </div>
      <p id="zt-anzahl-max" class="hinweis-text"></p>
    </div>

    <p id="zt-setup-fehler" class="fehler-text"></p>
    <p><button id="zt-starten" class="btn-primaer" hidden>Spiel starten</button></p>
    <p id="zt-setup-warten" hidden><em>Warte, bis der Spielleiter das Spiel startet …</em></p>
    <div id="zt-bereit-bereich" class="bereit-bereich" hidden></div>
  </div>

  <div id="zt-runde" class="bildschirm-karte" hidden>
    <p class="kategorie">10 Treffer!</p>
    <h1 id="zt-begriff" class="zt-begriff"></h1>
    <p id="zt-aktive-einheit" class="zt-aktive-einheit"></p>
    <div id="zt-timer" class="zt-timer" role="timer" aria-label="40 Sekunden verbleiben">
      <strong id="zt-timer-zahl">40</strong>
      <span>Sekunden</span>
    </div>

    <div id="zt-rater-ansicht" class="zt-rater-ansicht" hidden>
      <div class="zt-treffer-zaehler"><strong id="zt-rater-anzahl">0</strong><span>von 10</span></div>
      <p>Nennt möglichst viele Begriffe, Namen oder Dinge, die dazu passen.</p>
      <p class="hinweis-text">Die andere Seite markiert eure Treffer.</p>
    </div>

    <div id="zt-jury-ansicht" hidden>
      <p class="hinweis-text">Tippe einen Treffer an, sobald er gesagt wurde. Ein zweiter Tipp macht ihn wieder rückgängig.</p>
      <div id="zt-treffer-grid" class="zt-treffer-grid"></div>
    </div>

    <p id="zt-zuschauer-hinweis" class="zt-regel" hidden></p>
    <p id="zt-runden-status" class="zt-runden-status"></p>
    <p><button id="zt-runde-beenden" class="btn-flach" hidden>Runde beenden</button></p>
  </div>

  <div id="zt-auswertung" class="bildschirm-karte" hidden>
    <p class="kategorie">10 Treffer!</p>
    <h1 id="zt-auswertung-begriff" class="zt-begriff"></h1>
    <p id="zt-runden-ergebnis" class="zt-runden-ergebnis"></p>
    <div id="zt-auswertung-grid" class="zt-treffer-grid"></div>
    <div id="zt-zwischenstand"></div>
    <p><button id="zt-weiter" hidden>Nächste Runde</button></p>
  </div>

  <div id="zt-endstand" class="bildschirm-karte" hidden>
    <h1>Endstand</h1>
    <div id="zt-endstand-inhalt"></div>
    <p id="zt-endstand-warten" hidden><em>Der Spielleiter wählt gleich das nächste Spiel …</em></p>
    <p><button id="zt-gesamtwertung-btn" class="btn-primaer" type="button" hidden>Gesamtwertung</button></p>
  </div>
`;

let api = null;
let el = {};
let karten = [];
let spielerListe = [];
let raum = {};
let status = null;
let teammodus = false;
let teams = {};
let reihenfolge = [];
let gespielt = []; // Indizes der zuletzt gespielten Karten (fuer Wiederholungsschutz)
let spielerReihenfolge = [];
let startTeam = "blau";
let rundenIndex = 0;
let anzahlRunden = 0;
let aktiveId = null;
let aktivesTeamId = null;
let getroffen = [];
let punkte = {};
let teamPunkte = { blau: 0, rot: 0 };
let rundenpunkte = 0;
let rundeBeendenLaeuft = false;
let weiterLaeuft = false;
let anzahlManuellGesetzt = false;
let anzahlEntwurf = null;
let anzahlEntwurfTimer = null;
let rundenStartMs = null;
let timerIntervall = null;
let timerRundenSchluessel = null;
let letzterSignalton = null;
let audioKontext = null;
let audioFreischaltListener = null;

const $ = (id) => el.wurzel.querySelector("#" + id);

function karteAn(pos) {
  return karten[reihenfolge[pos]];
}

function spielerNachId(id) {
  return spielerListe.find((spieler) => spieler.id === id) ?? null;
}

function teamInfo(id) {
  return TEAMS[id] ?? { name: "Unbekanntes Team", emoji: "" };
}

function normalisiereTeam(team) {
  return team === "orange" ? "rot" : team;
}

function normalisiereTeams(werte) {
  return Object.fromEntries(
    Object.entries(werte || {}).map(([spielerId, team]) => [spielerId, normalisiereTeam(team)])
  );
}

function normalisiereTeamPunkte(werte) {
  return {
    blau: werte?.blau ?? 0,
    rot: werte?.rot ?? werte?.orange ?? 0
  };
}

function zeitpunktInMillis(wert) {
  if (Number.isFinite(wert)) return wert;
  if (typeof wert?.toMillis === "function") return wert.toMillis();
  if (Number.isFinite(wert?.seconds)) {
    return wert.seconds * 1000 + Math.floor((wert.nanoseconds ?? 0) / 1e6);
  }
  return null;
}

function audioAktivieren() {
  const AudioContext = window.AudioContext || window.webkitAudioContext;
  if (!AudioContext) return;
  try {
    if (!audioKontext) audioKontext = new AudioContext();
    if (audioKontext.state === "suspended") audioKontext.resume().catch(() => {});
  } catch { /* Der visuelle Countdown bleibt als Rückfall aktiv. */ }
}

function spieleSignalton(restsekunden) {
  audioAktivieren();
  if (!audioKontext || audioKontext.state !== "running") return;
  try {
    const jetzt = audioKontext.currentTime;
    const oscillator = audioKontext.createOscillator();
    const lautstaerke = audioKontext.createGain();
    const istSchlusston = restsekunden === 0;
    oscillator.type = istSchlusston ? "square" : "sine";
    oscillator.frequency.setValueAtTime(istSchlusston ? 420 : 880, jetzt);
    if (istSchlusston) oscillator.frequency.exponentialRampToValueAtTime(180, jetzt + 0.48);
    lautstaerke.gain.setValueAtTime(0.0001, jetzt);
    lautstaerke.gain.exponentialRampToValueAtTime(0.18, jetzt + 0.02);
    lautstaerke.gain.exponentialRampToValueAtTime(0.0001, jetzt + (istSchlusston ? 0.52 : 0.13));
    oscillator.connect(lautstaerke);
    lautstaerke.connect(audioKontext.destination);
    oscillator.start(jetzt);
    oscillator.stop(jetzt + (istSchlusston ? 0.54 : 0.15));
  } catch { /* Der visuelle Countdown bleibt als Rückfall aktiv. */ }
}

function verbleibendeSekunden() {
  if (!rundenStartMs) return RUNDEN_DAUER_SEKUNDEN;
  const ende = rundenStartMs + RUNDEN_DAUER_SEKUNDEN * 1000;
  return Math.max(0, Math.ceil((ende - Date.now()) / 1000));
}

function aktualisiereTimer() {
  if (!el.wurzel || status !== "runde") return;
  const timer = $("zt-timer");
  const anzeige = $("zt-timer-zahl");
  const rundenKarte = $("zt-runde");
  if (!timer || !anzeige || !rundenKarte) return;

  const restsekunden = verbleibendeSekunden();
  anzeige.textContent = restsekunden;
  timer.setAttribute("aria-label", `${restsekunden} Sekunden verbleiben`);
  timer.classList.toggle("warnung", restsekunden > 0 && restsekunden <= 5);
  timer.classList.toggle("abgelaufen", restsekunden === 0);
  rundenKarte.classList.toggle("zt-countdown-warnung", restsekunden <= 5);

  if (restsekunden <= 5 && restsekunden !== letzterSignalton) {
    letzterSignalton = restsekunden;
    spieleSignalton(restsekunden);
    if (restsekunden > 0) navigator.vibrate?.(55);
  }

  if (restsekunden === 0) {
    el.wurzel.querySelectorAll("#zt-treffer-grid .zt-treffer")
      .forEach((knopf) => { knopf.disabled = true; });
    if (api.istLeiter) rundeBeenden();
  }
}

function starteRundenTimer() {
  const schluessel = `${rundenIndex}:${rundenStartMs ?? "wartet"}`;
  if (timerRundenSchluessel !== schluessel) {
    timerRundenSchluessel = schluessel;
    letzterSignalton = null;
  }
  if (!timerIntervall) timerIntervall = window.setInterval(aktualisiereTimer, 100);
  aktualisiereTimer();
}

function stoppeRundenTimer() {
  if (timerIntervall) window.clearInterval(timerIntervall);
  timerIntervall = null;
  $("zt-runde")?.classList.remove("zt-countdown-warnung");
}

// Bereit-System (v190) - siehe kern/ui.js
let bereitSystem = null;
// v199: verhindert, dass der Bereit-Auto-Start (siehe zeigeSetup) mehrfach feuert.
let olympiadeAutoStart = false;

export async function starten(uebergebeneApi) {
  api = uebergebeneApi;
  el.wurzel = api.wurzel;
  el.wurzel.innerHTML = VORLAGE;
  bereitSystem = initBereitSystem(api, "zt");
  olympiadeAutoStart = false;

  if (karten.length === 0) {
    const antwort = await fetch(new URL("fragen.json", import.meta.url), { cache: "no-store" });
    if (!antwort.ok) throw new Error("fragen.json konnte nicht geladen werden");
    karten = await antwort.json();
  }

  verdrahteBedienelemente();

  if (api.istLeiter && !api.raum?.ztStatus) {
    await updateDoc(api.raumRef(), {
      ztStatus: "setup", ztTeammodus: false, ztTeams: {},
      ztReihenfolge: [], ztSpielerReihenfolge: [], ztStartTeam: "blau",
      ztRundenIndex: 0, ztAnzahlRunden: 0, ztAnzahlEntwurf: 0, ztAktiveId: null, ztAktivesTeam: null,
      ztGetroffen: [], ztPunkte: {}, ztTeamPunkte: { blau: 0, rot: 0 },
      ztRundenpunkte: 0, ztRundenStart: null
    });
  }

  // v196/v199: Olympiade - die Anzahl steht schon vorab fest, wird hier nur
  // vorbelegt (Tick warten, bis spielerListe gefuellt ist). Gestartet wird
  // trotzdem erst, wenn alle Mitspieler*innen "Bereit" geklickt haben - das
  // uebernimmt der Aufruf in zeigeSetup() weiter unten.
  // v201: die Anzahl wird nicht mehr hier vorbelegt, sondern bei jedem
  // Render in zeigeSetup() direkt aus api.olympiadeAnzahl gesetzt (siehe
  // dort) - das war vorher nur einmalig hier passiert und ist danach beim
  // naechsten Render wieder verlorengegangen.
}

function verdrahteBedienelemente() {
  audioFreischaltListener = audioAktivieren;
  el.wurzel.addEventListener("pointerdown", audioFreischaltListener);
  $("zt-teammodus").addEventListener("change", teammodusUmschalten);
  $("zt-team-wahl-blau").addEventListener("click", () => waehleEigenesTeam("blau"));
  $("zt-team-wahl-rot").addEventListener("click", () => waehleEigenesTeam("rot"));
  $("zt-teams-zufall").addEventListener("click", zufaelligeTeams);
  $("zt-anzahl").addEventListener("input", () => {
    const feld = $("zt-anzahl");
    const bereinigt = feld.value.replace(/[^0-9]/g, "");
    if (bereinigt !== feld.value) feld.value = bereinigt;
    anzahlManuellGesetzt = true;
    schreibeAnzahlEntwurfLive();
  });
  // v197: type="text" ignoriert das max-Attribut - ohne diese eigene
  // Begrenzung beim Verlassen des Feldes liesse sich eine beliebig hohe Zahl
  // eintippen, die stehen bliebe, bis sie beim Start still zurueckgestutzt wird.
  $("zt-anzahl").addEventListener("change", () => {
    const feld = $("zt-anzahl");
    let wert = parseInt(feld.value, 10);
    if (!Number.isFinite(wert) || wert < 1) wert = 1;
    if (wert > karten.length) wert = karten.length;
    feld.value = String(wert);
    anzahlManuellGesetzt = true;
  });
  // v105: als type="number" ließ sich der vorhandene Wert beim Fokussieren nicht
  // markieren - jetzt ein Textfeld mit numerischer Tastatur, select() funktioniert.
  $("zt-anzahl").addEventListener("focus", () => { $("zt-anzahl").select(); });
  $("zt-starten").addEventListener("click", spielStarten);
  $("zt-runde-beenden").addEventListener("click", rundeBeenden);
  $("zt-weiter").addEventListener("click", weiter);
}

// v214: Schreibt den vom Leiter eingegebenen "Anzahl"-Wert entprellt live in
// den Raum, damit Mitspieler*innen im Setup-Bildschirm sofort den
// tatsaechlichen Stand sehen statt eines stehengebliebenen Default-Werts.
function schreibeAnzahlEntwurfLive() {
  if (!api.istLeiter) return;
  clearTimeout(anzahlEntwurfTimer);
  anzahlEntwurfTimer = setTimeout(() => {
    const wert = parseInt($("zt-anzahl").value, 10);
    if (Number.isFinite(wert) && wert > 0) {
      updateDoc(api.raumRef(), { ztAnzahlEntwurf: wert }).catch(() => {});
    }
  }, 300);
}

export function beenden() {
  bereitSystem = null;
  stoppeRundenTimer();
  if (audioFreischaltListener && el.wurzel) {
    el.wurzel.removeEventListener("pointerdown", audioFreischaltListener);
  }
  audioFreischaltListener = null;
  audioKontext?.close?.().catch(() => {});
  audioKontext = null;
  el = {};
  karten = [];
  spielerListe = [];
  raum = {};
  status = null;
  teammodus = false;
  teams = {};
  reihenfolge = [];
  spielerReihenfolge = [];
  startTeam = "blau";
  rundenIndex = 0;
  anzahlRunden = 0;
  aktiveId = null;
  aktivesTeamId = null;
  getroffen = [];
  punkte = {};
  teamPunkte = { blau: 0, rot: 0 };
  rundenpunkte = 0;
  rundeBeendenLaeuft = false;
  weiterLaeuft = false;
  anzahlManuellGesetzt = false;
  anzahlEntwurf = null;
  rundenStartMs = null;
  timerRundenSchluessel = null;
  letzterSignalton = null;
}

export function spieler(liste) {
  spielerListe = liste;
  if (!el.wurzel) return;
  renderAktuellenStatus();
}

export function raumDaten(daten) {
  if (!daten || !el.wurzel) return;
  raum = daten;
  status = daten.ztStatus ?? null;
  teammodus = !!daten.ztTeammodus;
  teams = normalisiereTeams(daten.ztTeams);
  reihenfolge = daten.ztReihenfolge ?? [];
  gespielt = daten.ztGespielt ?? [];
  spielerReihenfolge = daten.ztSpielerReihenfolge ?? [];
  startTeam = normalisiereTeam(daten.ztStartTeam) ?? "blau";
  rundenIndex = daten.ztRundenIndex ?? 0;
  anzahlRunden = daten.ztAnzahlRunden ?? 0;
  anzahlEntwurf = daten.ztAnzahlEntwurf ?? null;
  aktiveId = daten.ztAktiveId ?? null;
  aktivesTeamId = normalisiereTeam(daten.ztAktivesTeam) ?? null;
  getroffen = bereinigeTreffer(daten.ztGetroffen, 10);
  punkte = daten.ztPunkte ?? {};
  teamPunkte = normalisiereTeamPunkte(daten.ztTeamPunkte);
  rundenpunkte = daten.ztRundenpunkte ?? 0;
  rundenStartMs = zeitpunktInMillis(daten.ztRundenStart);

  renderAktuellenStatus();

  if (api.istLeiter && status === "runde" && getroffen.length === 10) {
    rundeBeenden();
  }
}

function renderAktuellenStatus() {
  if (!el.wurzel) return;
  if (status !== "runde") stoppeRundenTimer();
  ["zt-setup", "zt-runde", "zt-auswertung", "zt-endstand"]
    .forEach((id) => { $(id).hidden = true; });

  // v112: "Begriff X von Y" steht jetzt oben im Spielkopf statt auf jedem
  // einzelnen Bildschirm separat (siehe api.fortschritt).
  api.fortschritt(
    status === "runde" || status === "auswertung" ? `${rundenIndex + 1}/${anzahlRunden}` : ""
  );

  if (status === "setup" || !status) {
    zeigeSetup();
    $("zt-setup").hidden = false;
  } else if (status === "runde") {
    zeigeRunde();
    $("zt-runde").hidden = false;
  } else if (status === "auswertung") {
    zeigeAuswertung();
    $("zt-auswertung").hidden = false;
  } else if (status === "beendet") {
    zeigeEndstand();
    $("zt-endstand").hidden = false;
  }
}

// v109: Teammodus - jeder Spieler wählt sich jetzt selbst ein Team (durch Klick
// auf die Team-Kachel). Nur der Spielleiter darf über "Zufällige Teams" alle
// Zuordnungen neu auswürfeln. Startet das Spiel, bevor alle gewählt haben,
// werden nur die fehlenden Spieler ausgeglichen zugeteilt (siehe
// ergaenzeFehlendeTeams) - bereits getroffene Wahlen bleiben erhalten.
async function teammodusUmschalten() {
  if (!api.istLeiter) return;
  const aktiviert = $("zt-teammodus").checked;
  const neueTeams = aktiviert ? teams : {};
  try {
    await updateDoc(api.raumRef(), { ztTeammodus: aktiviert, ztTeams: neueTeams });
  } catch (e) {
    $("zt-teammodus").checked = teammodus;
    zeigeDebug("Teammodus konnte nicht geändert werden: " + e.message);
  }
}

async function waehleEigenesTeam(team) {
  if (!teammodus) return;
  try {
    await updateDoc(api.raumRef(), { ztTeams: { ...teams, [api.spielerId]: team } });
  } catch (e) {
    zeigeDebug("Team konnte nicht gewählt werden: " + e.message);
  }
}

async function zufaelligeTeams() {
  if (!api.istLeiter || !teammodus) return;
  $("zt-teams-zufall").disabled = true;
  try {
    await updateDoc(api.raumRef(), {
      ztTeams: erstelleTeams(spielerListe.map((spieler) => spieler.id))
    });
  } catch (e) {
    zeigeDebug("Teams konnten nicht neu gemischt werden: " + e.message);
  }
  $("zt-teams-zufall").disabled = false;
}

function rendereTeamListe(team) {
  const liste = $("zt-team-" + team);
  liste.innerHTML = "";
  spielerListe.filter((spieler) => teams[spieler.id] === team).forEach((spieler) => {
    const li = document.createElement("li");
    li.textContent = spieler.name + (spieler.id === api.spielerId ? " (du)" : "");
    liste.appendChild(li);
  });
  if (!liste.children.length) {
    const li = document.createElement("li");
    li.textContent = "Noch niemand";
    liste.appendChild(li);
  }
  $("zt-team-wahl-" + team).classList.toggle("zt-team-eigenes", teams[api.spielerId] === team);
}

function zeigeSetup() {
  // v200: in der Olympiade entfaellt der Team-Modus komplett - alle spielen
  // einzeln, damit sich niemand extra dafuer koordinieren muss.
  const inOlympiade = Boolean(api.olympiadeAnzahl);
  if (inOlympiade) teammodus = false;
  $("zt-teammodus-zeile").hidden = inOlympiade;
  const teamSchalter = $("zt-teammodus");
  teamSchalter.checked = teammodus;
  teamSchalter.disabled = !api.istLeiter;
  $("zt-teams").hidden = !teammodus;
  $("zt-teams-zufall").hidden = !api.istLeiter;
  if (teammodus) {
    rendereTeamListe("blau");
    rendereTeamListe("rot");
  }

  const anzahlFeld = $("zt-anzahl");
  anzahlFeld.max = karten.length;
  if (inOlympiade) {
    // v201-Fix: vorher wurde die Anzahl nur einmalig beim Leiter per
    // setTimeout in starten() vorbelegt - jeder weitere zeigeSetup()-Aufruf
    // hat sie wieder auf "alle Begriffe" zurueckgesetzt (anzahlManuellGesetzt
    // blieb false), wodurch beim Auto-Start dann tatsaechlich ALLE Begriffe
    // statt der geplanten Anzahl gespielt wurden. api.olympiadeAnzahl ist
    // bei allen Clients gleichermaßen verfuegbar - bei jedem Render fest
    // darauf setzen und das Feld komplett sperren.
    const festgelegt = Math.min(Math.max(1, api.olympiadeAnzahl), karten.length);
    anzahlFeld.value = String(festgelegt);
    $("zt-anzahl-max").textContent = `In der Olympiade festgelegt: ${festgelegt} Begriff${festgelegt === 1 ? "" : "e"}.`;
    anzahlFeld.disabled = true;
  } else if (api.istLeiter) {
    if (!anzahlManuellGesetzt || !anzahlFeld.value) anzahlFeld.value = karten.length;
    $("zt-anzahl-max").textContent = `Insgesamt ${karten.length} Begriffe verfügbar.`;
    anzahlFeld.disabled = false;
  } else {
    anzahlFeld.value = String(anzahlEntwurf ?? karten.length);
    $("zt-anzahl-max").textContent = `Insgesamt ${karten.length} Begriffe verfügbar.`;
    anzahlFeld.disabled = true;
  }
  $("zt-anzahl-zeile").hidden = false;
  $("zt-starten").hidden = !api.istLeiter;
  $("zt-setup-warten").hidden = api.istLeiter;
  bereitSystem?.render();

  // v199: In der Olympiade ist die Anzahl schon vorab festgelegt, aber es
  // soll trotzdem ganz normal erst "Bereit" geklickt werden muessen - sobald
  // alle Mitspieler*innen bereit sind, startet das Spiel automatisch, ohne
  // dass der Leiter selbst noch auf "Spiel starten" tippen muss.
  if (api.istLeiter && api.olympiadeAnzahl && !olympiadeAutoStart && bereitSystem?.alleBereit()) {
    olympiadeAutoStart = true;
    spielStarten();
  }
}

async function spielStarten() {
  $("zt-setup-fehler").textContent = "";
  if (spielerListe.length < 2) {
    $("zt-setup-fehler").textContent = "Für 10 Treffer! braucht ihr mindestens zwei Spieler.";
    return;
  }

  let anzahl = parseInt($("zt-anzahl").value, 10);
  if (!Number.isFinite(anzahl) || anzahl < 1) anzahl = 1;
  if (anzahl > karten.length) anzahl = karten.length;

  // Wiederholungsschutz: bevorzugt Karten ziehen, die in diesem Raum noch
  // nicht drankamen (siehe kern/verlauf.js).
  const { kandidaten, wurdeZurueckgesetzt } = pooleOhneWiederholung(karten.map((_, index) => index), gespielt, anzahl);
  const neueReihenfolge = mischeListe(kandidaten).slice(0, anzahl);
  const neuerGespielt = aktualisierterVerlauf(gespielt, neueReihenfolge, wurdeZurueckgesetzt);

  const neueTeams = teammodus
    ? ergaenzeFehlendeTeams(teams, spielerListe.map((spieler) => spieler.id))
    : teams;
  const neueSpielerReihenfolge = mischeListe(spielerListe.map((spieler) => spieler.id));
  const neuerStart = Math.random() < 0.5 ? "blau" : "rot";
  const ersteAktiveId = teammodus ? null : neueSpielerReihenfolge[0];
  const erstesAktivesTeam = teammodus ? aktivesTeam(
    neuerStart, 0, neueTeams, spielerListe.map((spieler) => spieler.id)
  ) : null;

  $("zt-starten").disabled = true;
  try {
    await updateDoc(api.raumRef(), {
      ztStatus: "runde",
      ztTeammodus: teammodus,
      ztTeams: neueTeams,
      ztReihenfolge: neueReihenfolge,
      ztGespielt: neuerGespielt,
      ztSpielerReihenfolge: neueSpielerReihenfolge,
      ztStartTeam: neuerStart,
      ztRundenIndex: 0,
      ztAnzahlRunden: anzahl,
      ztAktiveId: ersteAktiveId,
      ztAktivesTeam: erstesAktivesTeam,
      ztGetroffen: [],
      ztPunkte: Object.fromEntries(spielerListe.map((spieler) => [spieler.id, 0])),
      ztTeamPunkte: { blau: 0, rot: 0 },
      ztRundenpunkte: 0,
      ztRundenStart: serverTimestamp()
    });
  } catch (e) {
    zeigeDebug("Fehler beim Start: " + e.message);
    $("zt-starten").disabled = false;
  }
}

function eigeneRolle() {
  if (teammodus) {
    const eigenesTeam = teams[api.spielerId] ?? null;
    if (!eigenesTeam) return "zuschauer";
    return eigenesTeam === aktivesTeamId ? "rater" : "jury";
  }
  return api.spielerId === aktiveId ? "rater" : "jury";
}

function aktiveEinheitText() {
  if (teammodus) {
    const info = teamInfo(aktivesTeamId);
    return `${info.emoji} ${info.name} rät`;
  }
  return `${spielerNachId(aktiveId)?.name ?? "Ein Spieler"} rät`;
}

function rendereTreffer(container, klickbar) {
  const karte = karteAn(rundenIndex);
  container.innerHTML = "";
  if (!karte) return;
  const markiert = new Set(getroffen);

  karte.treffer.forEach((treffer, trefferIndex) => {
    const knopf = document.createElement("button");
    knopf.type = "button";
    knopf.className = "zt-treffer" + (markiert.has(trefferIndex) ? " getroffen" : "");
    knopf.disabled = !klickbar;
    knopf.setAttribute("aria-pressed", markiert.has(trefferIndex) ? "true" : "false");
    knopf.innerHTML = `<span class="zt-haken">${markiert.has(trefferIndex) ? "✓" : ""}</span>` +
      `<span>${escapeHtml(treffer)}</span>`;
    if (klickbar) {
      knopf.addEventListener("click", () =>
        setzeTreffer(trefferIndex, !markiert.has(trefferIndex))
      );
    }
    container.appendChild(knopf);
  });
}

function zeigeRunde() {
  const karte = karteAn(rundenIndex);
  if (!karte) return;
  const rolle = eigeneRolle();
  $("zt-begriff").textContent = karte.begriff;
  $("zt-aktive-einheit").textContent = aktiveEinheitText();
  $("zt-rater-ansicht").hidden = rolle !== "rater";
  $("zt-jury-ansicht").hidden = rolle !== "jury";
  $("zt-zuschauer-hinweis").hidden = rolle !== "zuschauer";
  $("zt-zuschauer-hinweis").textContent = rolle === "zuschauer"
    ? "Du bist nach dem Spielstart beigetreten und kannst diese Runde nur zuschauen."
    : "";
  $("zt-rater-anzahl").textContent = getroffen.length;
  $("zt-runden-status").textContent = `${getroffen.length} von 10 Treffern`;
  $("zt-runde-beenden").hidden = !api.istLeiter;
  rendereTreffer($("zt-treffer-grid"), rolle === "jury");
  starteRundenTimer();
}

async function setzeTreffer(trefferIndex, sollGetroffenSein) {
  if (status !== "runde" || eigeneRolle() !== "jury" || verbleibendeSekunden() === 0) return;
  try {
    await runTransaction(api.db, async (transaktion) => {
      const ref = api.raumRef();
      const snap = await transaktion.get(ref);
      const daten = snap.data();
      if (!daten || daten.ztStatus !== "runde" || (daten.ztRundenIndex ?? 0) !== rundenIndex) return;
      const startMs = zeitpunktInMillis(daten.ztRundenStart);
      if (startMs && Date.now() >= startMs + RUNDEN_DAUER_SEKUNDEN * 1000) return;
      const aktuelle = bereinigeTreffer(daten.ztGetroffen, 10);
      const bereitsDabei = aktuelle.includes(trefferIndex);
      if (sollGetroffenSein === bereitsDabei) return;
      const neueTreffer = sollGetroffenSein
        ? bereinigeTreffer([...aktuelle, trefferIndex], 10)
        : aktuelle.filter((index) => index !== trefferIndex);
      transaktion.update(ref, { ztGetroffen: neueTreffer });
    });
  } catch (e) {
    zeigeDebug("Treffer konnte nicht gespeichert werden: " + e.message);
  }
}

async function rundeBeenden() {
  if (!api.istLeiter || status !== "runde" || rundeBeendenLaeuft) return;
  rundeBeendenLaeuft = true;
  $("zt-runde-beenden").disabled = true;
  try {
    await runTransaction(api.db, async (transaktion) => {
      const ref = api.raumRef();
      const snap = await transaktion.get(ref);
      const daten = snap.data();
      if (!daten || daten.ztStatus !== "runde" || (daten.ztRundenIndex ?? 0) !== rundenIndex) return;

      const anzahlTreffer = bereinigeTreffer(daten.ztGetroffen, 10).length;
      const neuePunkte = { ...(daten.ztPunkte ?? {}) };
      const neueTeamPunkte = normalisiereTeamPunkte(daten.ztTeamPunkte);
      if (daten.ztTeammodus) {
        const team = normalisiereTeam(daten.ztAktivesTeam);
        if (team === "blau" || team === "rot") {
          neueTeamPunkte[team] = (neueTeamPunkte[team] ?? 0) + anzahlTreffer;
        }
      } else if (daten.ztAktiveId) {
        neuePunkte[daten.ztAktiveId] = (neuePunkte[daten.ztAktiveId] ?? 0) + anzahlTreffer;
      }

      transaktion.update(ref, {
        ztStatus: "auswertung",
        ztRundenpunkte: anzahlTreffer,
        ztPunkte: neuePunkte,
        ztTeamPunkte: neueTeamPunkte,
        ztRundenStart: null
      });
    });
  } catch (e) {
    zeigeDebug("Runde konnte nicht beendet werden: " + e.message);
  }
  rundeBeendenLaeuft = false;
  if ($("zt-runde-beenden")) $("zt-runde-beenden").disabled = false;
}

function formatiertePunkte(wert) {
  const punktewert = Number(wert) || 0;
  return punktewert > 0 ? `+${punktewert}` : `${punktewert}`;
}

function zwischenstandHtml(mitRundenpunkten = true) {
  if (teammodus) {
    return `<div class="zt-punkte-grid">` +
      Object.keys(TEAMS).map((team) => {
        const mitglieder = spielerListe.filter((spieler) => teams[spieler.id] === team);
        const hinzugekommen = mitRundenpunkten && team === aktivesTeamId ? rundenpunkte : 0;
        return (
        `<div class="zt-punkte-team zt-team-${team}">` +
          `<strong class="zt-team-rundenpunkte">${formatiertePunkte(hinzugekommen)}</strong>` +
          `<div class="zt-punkte-team-info">` +
            `<span>${TEAMS[team].emoji} ${TEAMS[team].name}</span>` +
            `<div class="zt-team-avatare">${mitglieder.map((spieler) => avatarHtml(spieler.icon, "zt-team-avatar")).join("")}</div>` +
          `</div>` +
          `<strong class="zt-team-gesamtpunkte">${teamPunkte[team] ?? 0}</strong>` +
        `</div>`
        );
      }).join("") +
    `</div>`;
  }

  const sortiert = [...spielerListe].sort((a, b) =>
    (punkte[b.id] ?? 0) - (punkte[a.id] ?? 0)
  );
  return `<ul class="zt-punkteliste">` + sortiert.map((spieler, index) => {
    const gesamt = punkte[spieler.id] ?? 0;
    if (!mitRundenpunkten) {
      return `<li>${spielerKarte(spieler.name, spieler.farbe, spieler.icon, gesamt, { rang: index + 1 })}</li>`;
    }
    const hinzugekommen = spieler.id === aktiveId ? rundenpunkte : 0;
    return `<li>${spielerKarte(
      spieler.name, spieler.farbe, spieler.icon,
      formatiertePunkte(hinzugekommen),
      { punkteRechts: gesamt }
    )}</li>`;
  }).join("") + `</ul>`;
}

function zeigeAuswertung() {
  const karte = karteAn(rundenIndex);
  if (!karte) return;
  $("zt-auswertung-begriff").textContent = karte.begriff;
  $("zt-runden-ergebnis").textContent = `${aktiveEinheitText()}: ${rundenpunkte} von 10 Treffern`;
  rendereTreffer($("zt-auswertung-grid"), false);
  $("zt-zwischenstand").innerHTML = `<h3>Zwischenstand</h3>${zwischenstandHtml()}`;
  $("zt-weiter").hidden = !api.istLeiter;
  $("zt-weiter").disabled = weiterLaeuft;
  $("zt-weiter").textContent = rundenIndex + 1 >= anzahlRunden ? "Endstand anzeigen" : "Nächste Runde";
}

async function weiter() {
  if (!api.istLeiter || status !== "auswertung" || weiterLaeuft) return;
  weiterLaeuft = true;
  $("zt-weiter").disabled = true;
  const naechsterIndex = rundenIndex + 1;
  let erfolgreich = false;
  try {
    if (naechsterIndex >= anzahlRunden) {
      await updateDoc(api.raumRef(), { ztStatus: "beendet" });
      // Zehn Treffer! fuehrt seine Punkte selbst im Raum-Dokument (ztPunkte/ztTeamPunkte) -
      // anders als die anderen Spiele schreibt es NICHT auf das gemeinsame Spieler-Feld
      // "punkte". spielerListe[i].punkte war hier deshalb immer 0/undefined und die
      // Wertung hat diese Punkte nie erfasst. Im Teammodus gibt es zudem keine Punkte
      // pro Person, sondern nur pro Team - dafuer bekommt jede Person in der Wertung
      // den Punktestand ihres Teams zugeschrieben.
      const punkteProSpieler = Object.fromEntries(spielerListe.map((s) =>
        [s.id, teammodus ? (teamPunkte[teams[s.id]] ?? 0) : (punkte[s.id] ?? 0)]
      ));
      speichereWertung(api, "zehn-treffer", punkteProSpieler);
    } else {
      const ids = spielerListe.map((spieler) => spieler.id);
      await updateDoc(api.raumRef(), {
        ztStatus: "runde",
        ztRundenIndex: naechsterIndex,
        ztAktiveId: teammodus
          ? null
          : aktiveSpielerId(spielerReihenfolge, naechsterIndex, ids),
        ztAktivesTeam: teammodus
          ? aktivesTeam(startTeam, naechsterIndex, teams, ids)
          : null,
        ztGetroffen: [],
        ztRundenpunkte: 0,
        ztRundenStart: serverTimestamp()
      });
    }
    erfolgreich = true;
  } catch (e) {
    zeigeDebug("Fehler beim Weiterschalten: " + e.message);
  }
  weiterLaeuft = false;
  if (!erfolgreich && $("zt-weiter")) $("zt-weiter").disabled = false;
}

function teamEndstandHtml() {
  const sortiert = Object.keys(TEAMS).sort((a, b) =>
    (teamPunkte[b] ?? 0) - (teamPunkte[a] ?? 0)
  );
  const gleichstand = (teamPunkte.blau ?? 0) === (teamPunkte.rot ?? 0);
  return `<div class="zt-team-endstand">` + sortiert.map((team, index) => {
    const mitglieder = spielerListe.filter((spieler) => teams[spieler.id] === team);
    return `<section class="zt-team zt-team-${team} ${!gleichstand && index === 0 ? "gewinner" : ""}">` +
      `<h2>${!gleichstand && index === 0 ? "🏆 " : ""}${TEAMS[team].emoji} ${TEAMS[team].name}</h2>` +
      `<strong class="zt-team-punkte">${teamPunkte[team] ?? 0}</strong>` +
      `<p>${mitglieder.map((spieler) => escapeHtml(spieler.name)).join(", ")}</p>` +
    `</section>`;
  }).join("") + `</div>`;
}

function zeigeEndstand() {
  $("zt-endstand-inhalt").innerHTML = teammodus
    ? teamEndstandHtml()
    : zwischenstandHtml(false);
  $("zt-endstand-warten").hidden = api.istLeiter;
  // v202: in einer laufenden Olympiade fuehrt dieser Button jetzt zur
  // Gesamtwertung statt direkt zum naechsten Spiel - "Naechstes Spiel"
  // gibt es von dort aus als eigenen Button (siehe oeffneWertungDialog()
  // in app.js). So bleibt der eigene Endstand erst einmal sichtbar.
  const ztGesamtwertungBtn = $("zt-gesamtwertung-btn");
  if (ztGesamtwertungBtn) {
    ztGesamtwertungBtn.hidden = !(api.istLeiter && Boolean(api.olympiadeAnzahl));
    ztGesamtwertungBtn.onclick = () => api.zeigeGesamtwertung();
  }
}

// v104: der eigene "Zurück zur Spielauswahl"-Button (Setup- und Endstand-
// Bildschirm) ist entfernt, weil oben in der Kopfzeile bereits derselbe
// Button existiert (siehe gleiches Muster in spiele/schaetzfragen/spiel.js,
// Kommentar bei dessen "vorZurueck"). app.js ruft diesen exportierten Hook
// auf, bevor es zur Auswahl zurueckgeht, damit die Rundendaten trotzdem
// aufgeraeumt werden.
export async function vorZurueck() {
  try {
    await updateDoc(api.raumRef(), {
      ztStatus: null, ztTeammodus: false, ztTeams: {}, ztReihenfolge: [],
      ztSpielerReihenfolge: [], ztRundenIndex: 0, ztAnzahlRunden: 0, ztAnzahlEntwurf: 0,
      ztAktiveId: null, ztAktivesTeam: null, ztGetroffen: [],
      ztPunkte: {}, ztTeamPunkte: { blau: 0, rot: 0 }, ztRundenpunkte: 0,
      ztRundenStart: null
    });
    await api.zurueckZurAuswahl();
  } catch (e) {
    zeigeDebug("Fehler beim Zurückkehren: " + e.message);
  }
}
